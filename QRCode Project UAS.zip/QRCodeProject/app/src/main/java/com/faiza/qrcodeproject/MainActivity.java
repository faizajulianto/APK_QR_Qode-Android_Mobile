package com.faiza.qrcodeproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button goScan;
    public static final String URL_REGEX = "^((https?|ftp)://|(www|ftp)\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)+([/?].*)?$";
    public static final String PHONE_NUMBER_REGEX = "[0-9*#+() -]*";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        goScan = findViewById(R.id.btn_scan);
        goScan.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        IntentIntegrator intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.setPrompt("Arahkan kamera ke QRCode untuk di scan");
        intentIntegrator.setOrientationLocked(false);
        intentIntegrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (intentResult != null) {
            if (intentResult.getContents() == null) {
                Toast.makeText(getBaseContext(), "Dibatalkan", Toast.LENGTH_SHORT).show();
            } else {
                Pattern patternUrl = Pattern.compile(URL_REGEX);
                Matcher matcherUrl = patternUrl.matcher(intentResult.getContents());

                Pattern patternPhoneNumber = Pattern.compile(PHONE_NUMBER_REGEX);
                Matcher matcherPhoneNumber = patternPhoneNumber.matcher(intentResult.getContents());

                if (matcherUrl.find()) {
                    webViewCall(intentResult.getContents());
                    return;
                }

                if (matcherPhoneNumber.matches()) {
                    phoneCall(intentResult.getContents());
                    return;
                }

                if (validJSON(intentResult.getContents())) {
                    openJSON(intentResult.getContents());
                    return;
                }

                String[] latLng = intentResult.getContents().split(",");
                openMaps(latLng[0], latLng[1]);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void phoneCall(String phone) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phone));
        startActivity(intent);
    }

    public void webViewCall(String url) {
        Bundle bundle = new Bundle();
        bundle.putString("dataUrl", url);
        Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public boolean validJSON(String json) {
        try {
            new JSONObject(json);
        } catch (JSONException e) {
            try {
                new JSONArray(json);
            } catch (JSONException e0) {
                return false;
            }
        }
        return true;
    }

    public void openJSON(String json) {
        Bundle bundle = new Bundle();
        bundle.putString("dataJSON", json);
        Intent intent = new Intent(MainActivity.this, JSONViewActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void openMaps(String latitude, String longitude) {
        String uri = "http://maps.google.com/maps?q=loc:" + latitude + "," + longitude;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        startActivity(intent);
    }

    public void openAlamat(String alamat) {
        String at = "@gmail";
        if (alamat.contains(at)) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            String[] recipients = {alamat.replace("https//", "")};
            intent.putExtra(Intent.EXTRA_EMAIL, recipients);
            intent.putExtra(Intent.EXTRA_SUBJECT, "Subject Email");
            intent.putExtra(Intent.EXTRA_TEXT, "Type Here");
            intent.putExtra(Intent.EXTRA_CC, "");
            intent.setType("text/html");
            intent.setPackage("com.google.android.gm");
            startActivity(Intent.createChooser(intent, "Send mail"));
        }
    }
}